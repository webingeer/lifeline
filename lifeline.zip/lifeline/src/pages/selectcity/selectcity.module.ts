import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectcityPage } from './selectcity';

@NgModule({
  declarations: [
    SelectcityPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectcityPage),
  ],
})
export class SelectcityPageModule {}
