import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GivenservicesPage } from './givenservices';

@NgModule({
  declarations: [
    GivenservicesPage,
  ],
  imports: [
    IonicPageModule.forChild(GivenservicesPage),
  ],
})
export class GivenservicesPageModule {}
