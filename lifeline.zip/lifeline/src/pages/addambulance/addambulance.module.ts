import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddambulancePage } from './addambulance';

@NgModule({
  declarations: [
    AddambulancePage,
  ],
  imports: [
    IonicPageModule.forChild(AddambulancePage),
  ],
})
export class AddambulancePageModule {}
