import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EmergencytypePage } from './emergencytype';

@NgModule({
  declarations: [
    EmergencytypePage,
  ],
  imports: [
    IonicPageModule.forChild(EmergencytypePage),
  ],
})
export class EmergencytypePageModule {}
