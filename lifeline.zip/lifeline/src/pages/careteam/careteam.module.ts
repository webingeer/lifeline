import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CareteamPage } from './careteam';

@NgModule({
  declarations: [
    CareteamPage,
  ],
  imports: [
    IonicPageModule.forChild(CareteamPage),
  ],
})
export class CareteamPageModule {}
