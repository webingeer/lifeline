import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UserlocationPage } from './userlocation';

@NgModule({
  declarations: [
    UserlocationPage,
  ],
  imports: [
    IonicPageModule.forChild(UserlocationPage),
  ],
})
export class UserlocationPageModule {}
